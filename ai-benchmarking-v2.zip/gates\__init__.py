"""Acceptance gates."""
