"""Model-agnostic evaluation metrics."""
