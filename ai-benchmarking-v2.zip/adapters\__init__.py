"""Application adapters."""
