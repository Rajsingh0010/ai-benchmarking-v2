"""Computer-vision metrics."""
