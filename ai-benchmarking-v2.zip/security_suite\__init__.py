"""Offline safety checks."""
